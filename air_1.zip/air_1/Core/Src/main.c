/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdarg.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* ---------- 사용자 파라미터 ---------- */
#define RELAY_ACTIVE_LOW     1

#define ADC_VREF             3.3f
#define ADC_MAX              4095.0f
#define R_TOP_KOHM           5.1f
#define R_BOT_KOHM           10.0f
#define DIV_RATIO            (R_BOT_KOHM / (R_TOP_KOHM + R_BOT_KOHM))
#define KPA_FULL_SCALE       (-101.3f)

// === Relay alias (CubeMX가 만든 매크로와 매칭) ===
#define RELAY_Port  RELAY_VAC_GPIO_Port
#define RELAY_Pin   RELAY_VAC_Pin

/* 샘플링/필터 */
#define SAMPLE_PERIOD_MS     20
#define SMA_N                10

/* 판정 임계 & 안정성 */
#define ATTACH_KPA_ABS       60.0f   // 이 값 이상이면 부착으로 판단
#define DETACH_KPA_ABS       5.0f    // 이 값 이하이면 해제로 판단
#define STABLE_N             6       // 연속 만족 샘플 수

/* 타임아웃 */
#define ATTACH_TIMEOUT_MS    5000
#define DETACH_TIMEOUT_MS    3000

/* 상태 */
typedef enum { IDLE=0, WAIT_ATTACH, ATTACHED, WAIT_DETACH } ctrl_state_t;

/* UART RX 라인 버퍼(인터럽트 수신) */
#define RX_BUF_SZ 64
static volatile uint8_t  g_rx_byte;
static volatile uint32_t g_rx_len = 0;
static volatile bool     g_rx_line_ready = false;
static char              g_rx_buf[RX_BUF_SZ];

/* 런타임 상태 */
static ctrl_state_t g_state = IDLE;
static bool         g_relay_on = false;
static uint32_t     g_t_sample = 0;
static uint32_t     g_t_deadline = 0;
static int          g_stable = 0;

/* 필터 버퍼 */
static float  g_sma[SMA_N] = {0};
static int    g_sma_idx = 0, g_sma_filled = 0;

/* 최근 샘플(디버그/메시지용) */
static uint16_t g_raw = 0;
static float    g_vadc = 0, g_vsens = 0, g_kpa = 0, g_kpa_abs_sma = 0;

/* 전방 선언 */
static inline void relay_write(GPIO_TypeDef* p, uint16_t pin, bool on);
static uint16_t adc_read_raw_once(void);
static void sample_sensor(uint16_t* raw, float* v_adc, float* v_sens, float* kpa);
static void uart_printf(const char* fmt, ...);
static void start_rx_it(void);
static void handle_cmd_line(const char* s);
static int      uart_getc_nonblock(void);   // ← 이 줄 추가 (중요)

static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART3_UART_Init(void);

static volatile char g_key_cmd = 0;  // '1' 또는 '2' 들어오면 즉시 처리용



/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE BEGIN 2 */
  #if RELAY_ACTIVE_LOW
    HAL_GPIO_WritePin(RELAY_Port, RELAY_Pin, GPIO_PIN_SET);   // 릴레이 OFF(OD High)
  #else
    HAL_GPIO_WritePin(RELAY_Port, RELAY_Pin, GPIO_PIN_RESET); // OFF
  #endif

  g_state    = IDLE;
  g_t_sample = HAL_GetTick();

  uart_printf("\r\n[BOOT] ready. Send '1' to attach, '2' to detach.\r\n");
  /* USER CODE END 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    uint32_t now = HAL_GetTick();

    /* (A) UART 폴링: 개행 없이도 '1'/'2' 즉시 처리 */
    int c = uart_getc_nonblock();
    if (c > 0) {
      if (c=='1') {
        g_relay_on = true;  relay_write(RELAY_Port, RELAY_Pin, g_relay_on);
        g_state = WAIT_ATTACH;  g_t_deadline = now + ATTACH_TIMEOUT_MS;  g_stable = 0;
        uart_printf("[ACK] start vacuum (attach)\r\n");
      } else if (c=='2') {
        g_relay_on = false; relay_write(RELAY_Port, RELAY_Pin, g_relay_on);
        g_state = WAIT_DETACH;  g_t_deadline = now + DETACH_TIMEOUT_MS;  g_stable = 0;
        uart_printf("[ACK] release vacuum (detach)\r\n");
      } else if (c=='\r' || c=='\n') {
        /* 필요 시 라인 명령용 버퍼 마무리 */
        if (g_rx_len>0){ g_rx_buf[g_rx_len]=0; g_rx_len=0; }
      } else {
        if (g_rx_len < RX_BUF_SZ-1) g_rx_buf[g_rx_len++] = (char)c;
        else g_rx_len = 0;
      }
    }

    /* (B) 센서 주기 샘플 + 이동평균 */
    if ((int32_t)(now - g_t_sample) >= 0){
      g_t_sample += SAMPLE_PERIOD_MS;

      sample_sensor(&g_raw, &g_vadc, &g_vsens, &g_kpa);   // g_kpa: 음수
      float kpa_abs = -g_kpa;  if (kpa_abs < 0) kpa_abs = 0;

      g_sma[g_sma_idx] = kpa_abs;
      g_sma_idx = (g_sma_idx + 1) % SMA_N;
      if (g_sma_filled < SMA_N) g_sma_filled++;

      float sum = 0; for (int i=0;i<g_sma_filled;i++) sum += g_sma[i];
      g_kpa_abs_sma = sum / (float)g_sma_filled;
    }

    /* (C) 상태머신: 부착/해제 판정 */
    switch (g_state)
    {
      case WAIT_ATTACH:
        if (g_kpa_abs_sma >= ATTACH_KPA_ABS) {
          if (++g_stable >= STABLE_N){
            uart_printf("[ATTACHED] kPa_abs=%.1f (raw=%u, v_sens=%.3fV)\r\n",
                        g_kpa_abs_sma, g_raw, g_vsens);
            g_state = ATTACHED;
          }
        } else g_stable = 0;

        if ((int32_t)(now - g_t_deadline) >= 0 && g_state == WAIT_ATTACH){
          uart_printf("[ATTACH_TIMEOUT] kPa_abs=%.1f\r\n", g_kpa_abs_sma);
          g_state = IDLE;
        }
        break;

      case WAIT_DETACH:
        if (g_kpa_abs_sma <= DETACH_KPA_ABS) {
          if (++g_stable >= STABLE_N){
            uart_printf("[DETACHED] kPa_abs=%.1f (raw=%u, v_sens=%.3fV)\r\n",
                        g_kpa_abs_sma, g_raw, g_vsens);
            g_state = IDLE;
          }
        } else g_stable = 0;

        if ((int32_t)(now - g_t_deadline) >= 0 && g_state == WAIT_DETACH){
          uart_printf("[DETACH_TIMEOUT] kPa_abs=%.1f\r\n", g_kpa_abs_sma);
          g_state = IDLE;
        }
        break;

      default: /* IDLE / ATTACHED */ break;
    }
  }
  /* USER CODE END WHILE */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RELAY_VAC_GPIO_Port, RELAY_VAC_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : RELAY_VAC_Pin */
  GPIO_InitStruct.Pin = RELAY_VAC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RELAY_VAC_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
static uint16_t adc_read_raw_once(void)
{
  HAL_ADC_Start(&hadc1);
  if (HAL_ADC_PollForConversion(&hadc1, 10) != HAL_OK) {
    HAL_ADC_Stop(&hadc1);
    return 0;
  }
  uint16_t v = (uint16_t)HAL_ADC_GetValue(&hadc1);
  HAL_ADC_Stop(&hadc1);
  return v;
}


/* 릴레이 제어 */
static inline void relay_write(GPIO_TypeDef* p, uint16_t pin, bool on){
#if RELAY_ACTIVE_LOW
  HAL_GPIO_WritePin(p, pin, on ? GPIO_PIN_RESET : GPIO_PIN_SET);
#else
  HAL_GPIO_WritePin(p, pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
#endif
}

/* UART printf */
static void uart_printf(const char* fmt, ...){
  char buf[160];
  va_list ap; va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  if (n > 0) HAL_UART_Transmit(&huart3, (uint8_t*)buf, (uint16_t)n, HAL_MAX_DELAY);
}

/* UART 1바이트 폴링 수신 (인터럽트 없이도 동작) */
static int uart_getc_nonblock(void){
  if (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_RXNE)) {
    return (int)(huart3.Instance->RDR & 0xFF);   // 읽으면 클리어
  }
  return -1;
}

/* 센서 샘플 → 물리량 변환 */
static void sample_sensor(uint16_t* raw, float* v_adc, float* v_sens, float* kpa){
  uint16_t r = adc_read_raw_once();
  float vadc  = (r / ADC_MAX) * ADC_VREF;
  float vsens = vadc / DIV_RATIO;                // 1~5V
  if (vsens < 0.0f) vsens = 0.0f;
  if (vsens > 5.0f) vsens = 5.0f;
  float ratio = (vsens - 1.0f) / 4.0f;           // 0~1
  if (ratio < 0.0f) ratio = 0.0f;
  if (ratio > 1.0f) ratio = 1.0f;
  float k = ratio * KPA_FULL_SCALE;              // 음수

  if (raw)   *raw = r;
  if (v_adc) *v_adc = vadc;
  if (v_sens)*v_sens = vsens;
  if (kpa)   *kpa = k;
}

/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
