/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : BLDC DIR+VSP + SPI1 Encoder + UART Telemetry + PID Position
  * @note           : SPI1 8-bit + CPHA=2EDGE, PB8=TIM4_CH3 PWM(VSP), PB9=DIR
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
TIM_HandleTypeDef htim4;
UART_HandleTypeDef huart3;
PCD_HandleTypeDef hpcd_USB_OTG_FS;

/* USER CODE BEGIN PV */
/* ====================== 파라미터 ====================== */
#define ENC_RES_COUNTS           16384U
#define GEAR_RATIO               8.0f      /* input:output = 8:1 */

#define FILTER_WINDOW_SIZE       5
#define MAX_VALID_STEP_COUNTS    2048      /* ≈44deg: 글리치 억제 */

#define CTRL_DT_MS               10u
#define CTRL_DT_S                (0.01f)

/* 전역 듀티 제한(멀리 있을 때) */
#define DUTY_MIN_PERCENT         6.0f
#define DUTY_MAX_PERCENT         60.0f

/* 램프(듀티 변화율 제한) */
#define DUTY_RAMP_PCT_PER_STEP   1.0f      /* 3→1%로 더 부드럽게 */

/* ======= 근접 제어 ======= */
#define DEAD_BAND_DEG            3.0f      /* 이 안이면 완전 정지 + 적분 리셋 */
#define SLOW_BAND_DEG            30.0f     /* 가까워지면 속도 제한 시작 */
#define SLOW_MAX_DUTY            18.0f     /* 슬로우존 최대 듀티 */
#define SLOW_MIN_DUTY            11.0f      /* 슬로우존 최소 듀티(스틱-슬립 방지) */

/* ======= 자동 스텝(0→90→180→270→0 ...) ======= */
static const float STEP_SEQ[4] = {0.0f, 90.0f, 180.0f, 270.0f};
#define REACH_CONFIRM_TICKS      12        /* DEAD_BAND 안에서 12*10ms=120ms 유지 시 '도달' 확정 */

/*
 * ==============================================================================
 * [수정] PID 게인 튜닝 1단계: P 제어부터 시작하기 위한 초기값 설정
 * P-I-D 순서로 튜닝을 진행합니다. 먼저 I와 D를 0으로 설정합니다.
 * Kp 값을 0.1부터 서서히 올려가며 시스템이 진동하기 시작하는 지점을 찾고,
 * 그 값의 50~60%를 Kp로 설정합니다. 여기서는 예시 시작 값으로 0.4를 사용합니다.
 * ==============================================================================
 */
static float g_Kp = 0.63f;   /* P-제어 튜닝 시작 값 (조정 필요) */
static float g_Ki = 0.06f;   /* 튜닝 시작을 위해 0으로 설정 */
static float g_Kd = 0.03f;   /* 튜닝 시작을 위해 0으로 설정 */


/* 제어부호 정렬: +출력이 각도를 증가시킨다면 +1, 반대면 -1로 */
#define PLANT_SIGN               (-1)

/* ======= 런타임 상태 ======= */
static uint16_t enc_buf[FILTER_WINDOW_SIZE] = {0};
static int      enc_idx = 0;

static int32_t  input_unwrapped_counts = 0;
static uint16_t prev_used = 0;
static uint8_t  first_sample = 1;

/* 타깃은 '표시용 0~360'이 아니라, 스텝 시퀀스에서 선택 */
static float target_deg = 0.0f;

static float integral = 0.0f, prev_err = 0.0f;
static float last_u_01 = 0.0f;

static char tx_buf[96];

/* 스텝 진행 상태 */
static uint8_t step_idx = 0;
static uint16_t reach_cnt = 0;
/* USER CODE END PV */

/* Prototypes ---------------------------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM4_Init(void);

/* USER CODE BEGIN PFP */
static void BLDC_SetDutyPercent(float percent);
static void BLDC_SetDirection(uint8_t cw);
static uint16_t read_encoder_14bit(void);
static uint16_t movavg_push(uint16_t v);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
static inline uint32_t PWM_GetARR(void) { return __HAL_TIM_GET_AUTORELOAD(&htim4); }
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_SPI1_Init();
  MX_USART3_UART_Init();
  MX_TIM4_Init();

  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
  BLDC_SetDirection(1);
  BLDC_SetDutyPercent(0.0f);

  /* 초기 타깃은 스텝 시퀀스 0° */
  step_idx = 0;
  target_deg = STEP_SEQ[step_idx];

  uint32_t t0 = HAL_GetTick();
  float duty_prev = 0.0f;
  /* USER CODE END 2 */

  while (1)
  {
    uint32_t now = HAL_GetTick();
    if (now - t0 >= CTRL_DT_MS) {
      t0 += CTRL_DT_MS;

      /* 1) 엔코더 + 필터 */
      uint16_t raw = read_encoder_14bit();
      uint16_t flt = movavg_push(raw);

      /* 2) 언랩(필터값 사용) + 글리치 억제 */
      if (!first_sample) {
        int32_t d = (int32_t)flt - (int32_t)prev_used;
        if (d >  (int32_t)(ENC_RES_COUNTS/2))  d -= ENC_RES_COUNTS;
        if (d < -(int32_t)(ENC_RES_COUNTS/2))  d += ENC_RES_COUNTS;
        if (d >  MAX_VALID_STEP_COUNTS || d < -MAX_VALID_STEP_COUNTS) d = 0;
        input_unwrapped_counts += d;
      } else {
        first_sample = 0;
      }
      prev_used = flt;

      /* 3) 출력축 언랩 각도 */
      float input_total_deg  = (float)input_unwrapped_counts * (360.0f / (float)ENC_RES_COUNTS);
      float meas_deg_unwrap  = input_total_deg / GEAR_RATIO;          /* 연속 각도 */
      float meas_deg_display = fmodf(meas_deg_unwrap, 360.0f);
      if (meas_deg_display < 0) meas_deg_display += 360.0f;

      /* 4) 현재 타깃을 '가장 가까운 등가 타깃'으로 보정 */
      float x = (meas_deg_unwrap - target_deg) / 360.0f;
      int   k = (int)floorf(x + 0.5f);                /* round to nearest int */
      float target_near = target_deg + 360.0f * (float)k;

      /* 오차는 언랩 도메인에서 */
      float err = target_near - meas_deg_unwrap;

      /* ===== 도달 판정(연속 REACH_CONFIRM_TICKS 동안 DEAD_BAND 유지) ===== */
      if (fabsf(err) <= DEAD_BAND_DEG) {
        if (++reach_cnt >= REACH_CONFIRM_TICKS) {
          /* 다음 스텝으로 진행 */
          step_idx = (step_idx + 1) & 3;
          target_deg = STEP_SEQ[step_idx];

          /* 고정 직후 튕김 방지 */
          integral = 0.0f;
          prev_err = 0.0f;
          reach_cnt = 0;
        }
      } else {
        reach_cnt = 0;
      }

      /* 5) PID */
      float u = g_Kp * err;
      integral += (g_Ki * err) * CTRL_DT_S;
      if (integral >  1.0f) integral =  1.0f;
      if (integral < -1.0f) integral = -1.0f;
      float derr = (err - prev_err) / CTRL_DT_S;
      u += integral + (g_Kd * derr);
      prev_err = err;

      /* 6) 데드밴드/슬로우존 + 듀티/방향 */
      float abs_err = fabsf(err);
      float duty_tgt;

      // Deadband 조건을 제거하고 항상 PID 제어가 동작하도록 함
      float u_out = PLANT_SIGN * u;
      BLDC_SetDirection(u_out >= 0.0f ? 1 : 0);
      duty_tgt = fabsf(u_out);

      float max_duty = (abs_err <= SLOW_BAND_DEG) ? SLOW_MAX_DUTY : DUTY_MAX_PERCENT;
      float min_duty = (abs_err <= SLOW_BAND_DEG) ? SLOW_MIN_DUTY : DUTY_MIN_PERCENT;

      // ... 개선된 선형 매핑 로직 ...
      if (duty_tgt > max_duty) {
          duty_tgt = max_duty;
      } else if (duty_tgt > 0.001f) {
          duty_tgt = min_duty + (duty_tgt / max_duty) * (max_duty - min_duty);
      } else {
          duty_tgt = 0.0f; // PID 출력이 0에 가까우면 정지
      }

      /* 램프 */
      float delta = duty_tgt - duty_prev;
      if (delta >  DUTY_RAMP_PCT_PER_STEP)  delta =  DUTY_RAMP_PCT_PER_STEP;
      if (delta < -DUTY_RAMP_PCT_PER_STEP)  delta = -DUTY_RAMP_PCT_PER_STEP;
      float duty_cmd = duty_prev + delta;
      duty_prev = duty_cmd;

      BLDC_SetDutyPercent(duty_cmd);
      last_u_01 = duty_cmd / 100.0f;

      /* 7) 텔레메트리: meas,target,u,err (meas는 보기용 0~360) */
      int n = snprintf(tx_buf, sizeof(tx_buf), "%.2f,%.2f,%.3f,%.2f\r\n",
                       meas_deg_display, target_deg, last_u_01, err);
      HAL_UART_Transmit(&huart3, (uint8_t*)tx_buf, (uint16_t)n, 2);
    }
  }
}

/* ================= Peripherals ================= */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /* Configure the main internal regulator output voltage */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1); // F767은 고성능을 위해 SCALE1 권장

  /* Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure. */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Activate the Over-Drive mode */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /* Initializes the CPU, AHB and APB buses clocks */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_SPI1_Init(void)
{
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;         /* 8bit */
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;           /* 2EDGE */
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM4_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 95;                         /* 96MHz/96=1MHz */
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 49;                            /* 1MHz/50=20kHz */
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK) { Error_Handler(); }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3) != HAL_OK) { Error_Handler(); }

  HAL_TIM_MspPostInit(&htim4);
}

static void MX_USART3_UART_Init(void)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK) { Error_Handler(); }
}

static void MX_USB_OTG_FS_PCD_Init(void)
{
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 6;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  HAL_GPIO_WritePin(ENCODER_CS_GPIO_Port, ENCODER_CS_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, LD1_Pin|LD3_Pin|LD2_Pin|DIR_Pin, GPIO_PIN_RESET);

  /* ENCODER CS */
  GPIO_InitStruct.Pin = ENCODER_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ENCODER_CS_GPIO_Port, &GPIO_InitStruct);

  /* DIR */
  GPIO_InitStruct.Pin = DIR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* ================= Helpers ================= */

static uint16_t read_encoder_14bit(void)
{
  uint8_t tx[2] = {0,0}, rx[2] = {0,0};
  HAL_GPIO_WritePin(ENCODER_CS_GPIO_Port, ENCODER_CS_Pin, GPIO_PIN_RESET);
  for (volatile int i=0;i<30;i++); /* 짧은 지연 */
  HAL_SPI_TransmitReceive(&hspi1, &tx[0], &rx[0], 1, 50);
  HAL_SPI_TransmitReceive(&hspi1, &tx[1], &rx[1], 1, 50);
  HAL_GPIO_WritePin(ENCODER_CS_GPIO_Port, ENCODER_CS_Pin, GPIO_PIN_SET);
  uint16_t raw = ((uint16_t)rx[0] << 8) | rx[1];
  return (raw & 0x3FFF);
}

static uint16_t movavg_push(uint16_t v)
{
  enc_buf[enc_idx] = v;
  enc_idx = (enc_idx + 1) % FILTER_WINDOW_SIZE;
  uint32_t s=0; for (int i=0;i<FILTER_WINDOW_SIZE;i++) s += enc_buf[i];
  return (uint16_t)(s / FILTER_WINDOW_SIZE);
}

static void BLDC_SetDutyPercent(float percent)
{
  if (percent < 0.0f) percent = 0.0f;
  if (percent > 100.0f) percent = 100.0f;
  uint32_t arr = PWM_GetARR();
  uint32_t ccr = (uint32_t)((percent/100.0f)*(arr+1) + 0.5f);
  if (ccr > arr) ccr = arr;
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, ccr);
}

static void BLDC_SetDirection(uint8_t cw)
{
  HAL_GPIO_WritePin(GPIOB, DIR_Pin, cw ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/* Error Handler -------------------------------------------------------------*/
void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) { (void)file; (void)line; }
#endif
